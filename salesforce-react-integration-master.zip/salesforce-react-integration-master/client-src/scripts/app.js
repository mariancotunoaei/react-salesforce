var React = require('react'),
  ReactDOM = require('react-dom');

var App = require('./AppComponent.js');


ReactDOM.render(
  <App />,
  document.getElementById('content')
);
